// Get a reference to a CSInterface object
var csInterface = new CSInterface();

var validFileFound = false;

var btnFilePath = window.document.getElementById("btn-file-path");
var btnGenerate = window.document.getElementById("btn-generate");
var inputTxtBox = window.document.getElementById("file-path-box");

btnFilePath.addEventListener("click", chooseFile);

function chooseFile() {
	validFileFound = false;
	csInterface.evalScript("getMarkerFile()", 
		function(chosenFilePath)
		{
			if (chosenFilePath != "")
			{
				validFileFound = true;
				inputTxtBox.value = chosenFilePath;
			}
		}
	);
};


btnGenerate.onclick = function() {
	if (validFileFound)
	{
		csInterface.evalScript("ctrlExecution ()");
	}
};
